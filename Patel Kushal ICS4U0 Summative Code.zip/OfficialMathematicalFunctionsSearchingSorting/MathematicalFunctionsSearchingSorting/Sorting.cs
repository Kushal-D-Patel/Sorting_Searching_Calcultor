﻿using System;
using System.Collections.Generic;

namespace MathematicalFunctionsSearchingSorting
{
    #region Purpose of this Class
    /*
    * The 'Sorting' class is being used only as a storage place for sorting methods. It is not intended to be
    * used as a template for making objects. In fact, it CANNOT be used as such because it does not contain
    * any constructor methods (done intentionally). Recall that constructor methods are called to initialize
    * objects. Since this class cannot be used to create objects, there is no need for any constructors.
    */
    #endregion

    public static class Sorting
    {
        // Constructor has been removed because of reasons specified in the last comment.
        //public Sort()
        //{
        //}

        #region Explanation of Time Complexity

        /**************************************************************************************************
         * 
         * The "time complexity" (sometimes also known informally as "running time") of an algorithm is a 
         * measure of "how fast" it is. For comparison-based sorting algorithms, time complexity generally 
         * refers to the number of comparisons required to sort a list/array containing n items. In general, 
         * it is extremely difficult to determine the exact number of comparisons needed to sort lists 
         * because this depends largely on the initial ordering of the data and other complicating factors. 
         *  
         * Because of this, computer scientists prefer to specify upper bounds on the number of comparisons
         * required. Most of the sorting algorithms that we have studied have an average time complexity
         * denoted by O(n^2). This is read "order n squared" and it means that to sort n items, no more
         * than an^2 + bn + c comparisons are required, where a, b and c are constants that differ from
         * one algorithm to another. That is, the number of comparisons is no greater than some quadratic
         * function of n.
         * 
         * The fastest comparison-based sorting algorithms have an average time complexity of O(nlogn). 
         * Even for such algorithms, worst-case performance can still be O(n^2).
         * 
         * See https://en.wikipedia.org/wiki/Sorting_algorithm#Comparison_of_algorithms for a detailed
         * comparison of the best-, worst- and average-case time complexity of a wide variety of different
         * sorting algorithms. This source also gives information on space complexity (memory requirements)
         * and stability (see next comment).
         * 
         **************************************************************************************************/
        #endregion

        #region General Comments on Sorting Algorithms

        /*
         * General Comments about the Sorting Algorithms Implemented Below
         *
         * The implementations have some desirable features.
         * 
         * 1. They are all "IN-PLACE" implementations, which means that the data are sorted entirely within the  
         *    given lists. No additional lists or arrays are used, which makes the most efficient use of memory.
         *    
         * 2. They do not RETURN sorted lists, because this would also require additional memory. Instead, they  
         *    directly alter the lists passed to them. This happens because 'List<>' is a reference type.
         * 
         *    e.g. Sorting.SelectionSort(numberList); 
         *
         *       → 'numberList' is A REFERENCE to the data stored in the list
         *       → This reference is copied to 'l' (the method's parameter)
         *       → Within the method, 'l' refers to the same list as 'numberList'
         *       → Any change made to the list IS A CHANGE in the SINGLE copy of the list stored in RAM.

         * 
         * STABLE versus UNSTABLE Sorting Algorithms
         * Stable sorting algorithms ALWAYS preserve the initial order of identical items/elements (i.e. the 
         * order of identical items/elements in the input). Unstable sorting algorithms, on the other hand, do
         * not always preserve this order. This isn't important at all when sorting records that contain only
         * one field. However, it is very important when records contain multiple fields. In the latter case,
         * stable sorts always preserve the initial order of records with identical keys.
         *   
         * e.g. Record: | lastName | firstName | address | telephone number | 
         *      Suppose that the key is 'lastName'. Stable sorts will maintain the initial order of the records 
         *      by 'lastName.' Unstable sorts don't necessarily preserve this order. 
         *      See https://en.wikipedia.org/wiki/Sorting_algorithm#Stability for more information.
         */

        #endregion

        #region Sorting Methods
                
        /// <summary>
        /// <i>SelectionSort</i> uses the selection sort algorithm to sort the given list of <i>double</i> values in 
        /// ascending order. The average time complexity of selection sort is O(n^2) comparisons.
        /// Selection sort is UNSTABLE.
        /// </summary>
        /// <param name="l">Any list of <i>double</i> values</param>
        public static void SelectionSort(List<double> l)
        {
            for (int i = 0; i < l.Count; i++)
            {
                //Find index of smallest value from index 'i' to index 'l.Count - 1'
                int minIndex = i;

                for (int j = i + 1; j < l.Count; j++)
                {
                    if (l[j] < l[minIndex])
                    {
                        minIndex = j;
                    }
                }

                //Swap item 'i' with item 'minIndex'
                double copy = l[i];
                l[i] = l[minIndex];
                l[minIndex] = copy;
            }
        }

        /// <summary>
        /// <i>BubbleSort</i> uses the bubble sort algorithm to sort the given list of <i>double</i> values in 
        /// ascending order. The average time complexity of bubble sort is O(n^2) comparisons.
        /// Bubble sort is STABLE.
        /// </summary>
        /// <param name="l">Any list of <i>double</i> values</param>
                
        public static void BubbleSort(List<double> l)
        {
            int n = l.Count;
            for (int i = 0; i < n - 1; i++)
            {
                for (int j = 0; j < n - i - 1; j++)
                {
                    if (l[j] > l[j + 1]) //if the jth element is greater than the next element, switch them
                    {
                        double temp = l[j]; 
                        l[j] = l[j + 1];
                        l[j + 1] = temp;
                    }
                }
            }
        }

        /// <summary>
        /// <i>CocktailSort</i> uses the cocktail sort algorithm to sort the given list of double values in 
        /// ascending order. The average time complexity of cocktail sort is O(n^2) comparisons.
        /// Cocktail sort is STABLE.
        /// </summary>
        /// <param name="l">Any list of <i>double</i> values</param>
        
        public static void CocktailSort(List<double> l)
        {
            bool swapped = true;
            int start = 0;
            int end = l.Count;

            while (swapped == true)
            {
                swapped = false;
                for (int i = start; i < end - 1; i++) //bubble sort going forwards
                {
                    if (l[i] > l[i + 1]) 
                    {
                        double temp = l[i];
                        l[i] = l[i + 1];
                        l[i + 1] = temp;
                        swapped = true;
                    }
                }
                if (swapped == false)
                {
                    break;
                }
                swapped = false;
                end--;
                for (int i = end - 1; i >= start; i--) //bubble sort going backwards
                {
                    if (l[i] > l[i + 1])
                    {
                        double temp = l[i];
                        l[i] = l[i + 1];
                        l[i + 1] = temp;
                        swapped = true;
                    }
                }
                start++;
            }
        }

        /// <summary>
        /// <i>InsertionSort</i> uses the insertion sort algorithm to sort the given list of double values in 
        /// ascending order. The average time complexity of insertion sort is O(n^2) comparisons.
        /// Insertion sort is STABLE.
        /// </summary>
        /// <param name="l">Any list of <i>double</i> values</param>
     
        public static void InsertionSort(List<double> l)
        {
            for (int i = 0; i < l.Count; i++)
            {
                double insertionValue = l[i];
                int j = i - 1;
                while (j>=0&&l[j]>insertionValue) //Move elements of l[0...i-1], that are greater than insertionValue, to one position ahead of their current position
                {
                    l[j + 1] = l[j];
                    j--;
                }
                l[j+1] = insertionValue;
            }
        }

        
        /// <summary>
        /// <i>ShellSort</i> uses the Shell sort algorithm to sort the given list of double values in ascending
        /// order. The time complexity of Shell sort depends a great deal on the sequence of gap sizes
        /// (h-values) used. It's very difficult to determine the average time complexity of Shell sort
        /// but it's conjectured to be O(n^(5/4))=O(n^1.25) comparisons (much better than quadratic). 
        /// Shell sort is UNSTABLE.
        /// </summary>
        /// <param name="l">Any list of <i>double</i> values</param>
        public static void ShellSort(List<double> l)
        {
            int n = l.Count;
            for (int gap = n / 2; gap > 0; gap /= 2) //start with a big gap, then reduce
            {
                for (int i = gap; i < n; i ++) //do a gapped insertion sort
                {
                    double temp = l[i];
                    int j;
                    for (j = i; j >= gap && l[j - gap] > temp; j -= gap)
                    {
                        l[j] = l[j - gap];
                    }
                    l[j] = temp;
                }
            }
        }

        // Description of Quicksort Algorithm:
        // The first step is to divide the sublist of 'l' that runs from index 'left' to index 'right',
        // inclusive, into two parts about a "pivot" value. The pivot can be chosen in a variety of ways. This 
        // implementation uses the "middle" item of this sublist. (See comments below.) After partitioning is
        // completed, this sublist takes the following form: (Left Partition) + Pivot + (Right Partition), where
        // (Left Partition) consists of all items <= pivot and (Right Partition) consists of all items >= pivot.

        /// <summary>
        /// <i>QuickSort</i> uses the quicksort algorithm to sort the sublist of <i>l</i> that runs 
        /// from index <i>left</i> to index <i>right</i>, inclusive, in ascending order.
        /// The average time complexity of quick sort is O(nlogn) comparisons. The worst-case performance of 
        /// quicksort is O(n^2) comparisons, but this occurs only in special cases. Quicksort is UNSTABLE (although there 
        /// are stable variants). When <i>QuickSort</i> is called with <i>left</i> = 0 and <i>right</i> = listSize - 1,
        /// the entire list is sorted.
        /// </summary>
        /// <param name="l">Any list of <i>double</i> values</param>
        /// <param name="left">The leftmost index of the sublist</param>
        /// <param name="right">The rightmost index of the sublist</param>
        public static void QuickSort(List<double> l, int left, int right)
        {
            if (left < right)
            {
                int pi = LomutoPartition(l, left, right); //pi is patritioning index
                //Seperately sort elements before patrition and after patrition
                QuickSort(l, left, pi - 1);
                QuickSort(l, pi + 1, right);
            }
        }
        #endregion

        #region Partitioning Methods

        // The pivot for quicksort can be chosen in a variety of ways. For the sake of simplicity, all the methods below 
        // use the "middle" item of the sublist running from 'left' to 'right'. This turns out to be a 
        // good choice to prevent worst-case performance caused by applying quicksort to a list that's
        // already sorted. Even better choices are possible.
        // See https://en.wikipedia.org/wiki/Quicksort#Choice_of_pivot for details.

        /// <summary>
        /// 'NaivePartition' divides the sublist of <i>l</i> that runs from index <i>left</i> to index <i>right</i>, inclusive, 
        /// into two parts about a "pivot" value. The pivot can be chosen in a variety of ways.  After partitioning is
        /// completed, this sublist takes the form (Left Partition) + Pivot + (Right Partition), where
        /// (Left Partition) consists of all items ≤ pivot and (Right Partition) consists of all items ≥ pivot.
        /// </summary>
        /// <param name="l">Any list of <i>double</i> values</param>
        /// <param name="left">The leftmost index of the sublist</param>
        /// <param name="right">The rightmost index of the sublist</param>
        public static int NaivePartition(List<double> l, int left, int right)
        {
            // This partitioning method is the first thing that occurred to me when I did my best to forget what I already
            // knew about quicksort. Upon reflection, I realized that in spite of the simplicity of my algorithm, 
            // it turned out to be very inefficient. Better algorithms, Lomuto partition and Hoare partition, are
            // given below. The average time complexity of both algorithms is O(n) comparisons, although the Hoare method 
            // can be shown to be the more efficient of the two. 
            // 
            // Unfortunately, it turns out that my naive algorithm's time complexity is O(n^2) comparisons, which 
            // completely nullifies the speed advantages of quicksort.
            int pivotIndex = -1;

            // Partition the sublist from index 'left' to index 'right' as described above.

            if (left < right && left >= 0 && right < l.Count)
            {
                pivotIndex = (left + right) / 2; // This could cause an overflow exception
                int smallerThanPivot = -1; // Don't count pivot itself
                double pivot = l[pivotIndex];

                // Count how many values are smaller than or equal to the pivot
                // Requires 'left - right + 1' comparisons (i.e. 'n' comparisons)
                for (int i = left; i <= right; i++)
                {
                    if (l[i] <= pivot)
                    {
                        smallerThanPivot++;
                    }
                }

                // Move the pivot to its final resting place by swapping
                int originalPivotIndex = pivotIndex;
                pivotIndex = left + smallerThanPivot;
                l[originalPivotIndex] = l[pivotIndex];
                l[pivotIndex] = pivot;

                // Now partition the list about pivot (which is found at index 'pivotIndex')
                // Outer loop requires 'pivotIndex - left' comparisons (i.e. n/2 comparsions on average)
                for (int i = left; i < pivotIndex; i++)
                {
                    if (l[i] > pivot)
                    {
                        //Find a value in the right partition that is smaller than pivot.
                        int j = pivotIndex + 1;

                        // This loop requires up to 'right - pivot' comparisons. On average, 
                        // it requires '(right - pivot)/2' comparisons (i.e. n/2 comparsions on average).
                        while (l[j] > pivot)
                        {
                            j++;
                        }

                        //Then exchange it with l[i].
                        double copy = l[j];
                        l[j] = l[i];
                        l[i] = copy;
                    }
                }
            }

            return pivotIndex;
        }

        /// <summary>
        /// 'LomutoPartition' divides the sublist of <i>l</i> that runs from index <i>left</i> to index <i>right</i>, inclusive, 
        /// into two parts about a "pivot" value. After partitioning is completed,
        /// this sublist takes the following form: (Left Partition) + <i>pivot</i> + (Right Partition), where
        /// (Left Partition) consists of all items ≤ <i>pivot</i> and (Right Partition) consists of all items >= <i>pivot</i>.
        /// The Lomuto partition algorithm, attributed to Nico Lomuto, is simpler and faster than the naive 
        /// algorithm used above. Unlike the above algorithm, it requires only one pass of the data. 
        /// The average time complexity of the Lomuto scheme is O(n) comparisons.
        /// </summary>
        /// <param name="l">Any list of <i>double</i> values</param>
        /// <param name="left">The leftmost index of the sublist</param>
        /// <param name="right">The rightmost index of the sublist</param>

        public static int LomutoPartition(List<double> l, int left, int right)
        {
            int pivotIndex = -1;

            // Partition the sublist from index 'left' to index 'right' as described above.

            if (left < right && left >= 0 && right < l.Count)
            {
                pivotIndex = left + (right - left) / 2; // Immune from overflow exception
                double pivot = l[pivotIndex];

                // Move 'pivot' to the (right) end by swapping.
                l[pivotIndex] = l[right];
                l[right] = pivot;

                // Assume at first that the pivot's final resting place is at index 'left'
                pivotIndex = left;

                // Each time a value smaller than the 'pivot' is found, exchange it with 
                // l[pivotIndex] and increase 'pivotIndex' by 1.
                for (int i = left; i < right; i++)
                {
                    if (l[i] <= pivot)
                    {
                        double copy = l[pivotIndex];
                        l[pivotIndex] = l[i];
                        l[i] = copy;
                        pivotIndex++;
                    }
                }

                // Move the pivot to its final resting place by swapping 
                l[right] = l[pivotIndex];
                l[pivotIndex] = pivot;
            }

            return pivotIndex;
        }

        /// <summary>
        /// 'HoarePartition' divides the sublist of <i>l</i> that runs from index <i>left</i> to index <i>right</i>, inclusive, 
        /// into two parts called the "Left Partition" and the "Right Partition". After partitioning is completed,
        /// this sublist takes the following form: (Left Partition) + (Right Partition), where each item in
        /// (Left Partition) is ≤ each item in (Right Partition).
        /// The average time complexity of the Hoare partitioning scheme is O(n) comparisons.
        /// </summary>
        /// <param name="l">Any list of <i>double</i> values.</param>
        /// <param name="left">The leftmost index of the sublist.</param>
        /// <param name="right">The rightmost index of the sublist.</param>

        public static int HoarePartition(List<double> l, int left, int right)
        {
            //****NOTE: The Hoare partitioning scheme is a little different from the previous two.* ***
            // The Hoare partition algorithm was introduced by C. A. R. Hoare (aka Tony Hoare), the inventor 
            // of quicksort. It is even more efficient than the Lomuto method BUT is somewhat more difficult 
            // to understand and implement. It uses two variables, 'i' and 'pivotIndex', to store index values   
            // that are initially at opposite ends of the list. The values of these two variables "move" toward   
            // each other, 'i' increasing by one whenever 'l[i]' < 'pivot', and 'pivotIndex' decreasing by one 
            // whenever 'l[pivotIndex]' > 'pivot'. When values 'l[pivotIndex]' and 'l[i]' are found to be in the  
            // wrong order relative to 'pivot', they are swapped. This continues as long as 'i' < 'pivotIndex'.
            // 
            // ****VERY IMPORTANT NOTE!****
            // The Hoare partitioning scheme does NOT necessarily return the index of the final resting place of the 
            // pivot! It only guarantees that the all items with indices ≤ 'pivotIndex' are smaller than all items
            // with indices > 'pivotIndex'.
      
            // Partition the sublist from index 'left' to index 'right' as described above.
            int pivotIndex = -1;

            if (left < right && left >= 0 && right < l.Count)
            {
                double pivot = l[left + (right - left) / 2]; // Immune from overflow exception
                int i = left - 1;
                pivotIndex = right + 1;

                while (i < pivotIndex)
                {
                    // Starting from the left, loop until a value is found that is >= 'pivot'
                    do
                    {
                        i++;
                    } while (l[i] < pivot);

                    // Starting from the right, loop until a value is found that is <= 'pivot'
                    do
                    {
                        pivotIndex--;
                    } while (l[pivotIndex] > pivot);

                    if (i < pivotIndex)
                    {
                        // Swap l[i] with l[pivotIndex] because they are out of order relative to 'pivot'
                        double copy = l[i];
                        l[i] = l[pivotIndex];
                        l[pivotIndex] = copy;
                    }
                }
            }

            return pivotIndex;
        }

        #endregion

        #region Scrambling (Shuffling)

        /// <summary>
        /// <i>Scramble</i> "shuffles" any list of <i>double</i> values. That is, it arranges the items
        /// of the list in a random order.
        /// </summary>
        /// <param name="l">Any list of <i>double</i> values</param>
        public static void Scramble(List<double> l)
        {
            // Create a 'Random' object
            Random randomNumberGenerator = new Random();

            for (int i = 0; i < l.Count; i++)
            {
                int randomIndex = randomNumberGenerator.Next(0, l.Count);

                // Swap item 'i' with item 'randomIndex'
                double copy = l[i];
                l[i] = l[randomIndex];
                l[randomIndex] = copy;
            }
        }

        #endregion
    }
}