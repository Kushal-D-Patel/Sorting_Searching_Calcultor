﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace MathematicalFunctionsSearchingSorting
{
    public static class Searching
    {
        #region Linear Search

        /// <summary>
        /// <i>LinearSearch</i> uses the linear search algorithm to find a value in a list of <i>double</i> values.
        /// </summary>
        /// <param name="l">Any list of <i>double</i> values.</param>
        /// <param name="key">The value to find in the list.</param>
        /// <returns> 
        /// The index of the first occurrence of <i>key</i> if <i>key</i> is found, -1 otherwise.
        /// </returns>

        public static int LinearSearch(List<double> l, double key)
        {
            int index = -1, i = 0;

            while (i < l.Count && l[i] != key)
            {
                i++;
            }

            // The value of 'i' can only equal 'l.Count' if 'key' was not found
            if (i < l.Count)
            {
                index = i;
            }

            return index;
        }

        /// <summary>
        /// <i>LinearSearch</i> uses the linear search algorithm to find a value in an array of <i>double</i> values.
        /// </summary>
        /// <param name="a">Any array of <i>double</i> values.</param>
        /// <param name="key">The value to find in the list.</param>
        /// <returns> 
        /// The index of the first occurrence of <i>key</i> if <i>key</i> is found, -1 otherwise.
        /// </returns>

        public static int LinearSearch(double[] a, double key)
        {
            int index = -1, i = 0;

            while (i < a.Length && a[i] != key)
            {
                i++;
            }

            // The value of 'i' can only equal 'l.Count' if 'key' was not found
            if (i < a.Length)
            {
                index = i;
            }

            return index;
        }

        #endregion

        #region Binary Search

        /// <summary>
        /// <i>BinarySearch</i> uses the binary search algorithm to find a value in a list of <i>double</i> values.
        /// </summary>
        /// <param name="l">Any list of <i>double</i> values.</param>
        /// <param name="key">The value to find in the list.</param>
        /// <returns> 
        /// The index of the first occurrence of <i>key</i> if <i>key</i> is found, -1 otherwise.
        /// </returns>

        public static int BinarySearch(List<double> l, double key)
        {
            l.Sort();
            int index = -1, left = 0, right = l.Count;
            while (left < right)
            {
                int mid = (left + right) / 2;
                if (key == l[mid])
                {
                    index = mid;
                    break;
                }
                else if (key < l[mid])
                {
                    right = mid; //ignore right half of the list by setting the right boundary to the middle index
                }
                else
                {
                    left = mid + 1; //ignore left half of the list by setting the left boundary to the index after the middle index
                }
            }

            return index;
        }

        /// <summary>
        /// <i>BinarySearch</i> uses the binary search algorithm to find a value in an array of <i>double</i> values.
        /// </summary>
        /// <param name="a">Any array of double values.</param>
        /// <param name="key">The value to find in the list.</param>
        /// <returns> 
        /// The index of the first occurrence of <i>key</i> if <i>key</i> is found, -1 otherwise.
        /// </returns>

        public static int BinarySearch(double[] a, double key)
        {
            Array.Sort(a);
            int index = -1, left = 0, right = a.Length;
            while (left < right)
            {
                int mid = (left + right) / 2;
                if (key == a[mid])
                {
                    index = mid;
                    break;
                }
                else if (key < a[mid])
                {
                    right = mid; //ignore right half of the list by setting the right boundary to the middle index
                }
                else
                {
                    left = mid + 1; //ignore left half of the list by setting the left boundary to the index after the middle index
                }
            }

            return index;
        }
        #endregion
    }

}
