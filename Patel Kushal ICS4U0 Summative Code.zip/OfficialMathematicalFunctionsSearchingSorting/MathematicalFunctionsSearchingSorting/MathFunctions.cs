﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace MathematicalFunctionsSearchingSorting
{
    public static class MathFunctions
    {
        // Below you will find several examples of OVERLOADING. Multiple procedures (called 
        // "methods" when they are defined within classes) can have the SAME NAME as long as 
        // their parameters differ in either NUMBER or TYPE.

        #region Measures of Central Tendency

        /// <summary>
        /// 'ArithmeticMean' finds the arithmetic mean of a list of <i>double</i> values.
        /// </summary>
        /// <param name="l">
        /// Any list of <i>double</i> values.
        /// </param>
        /// <returns> 
        /// The arithmetic mean (average) of the values in <i>l</i>.
        /// If <i>l</i> is empty, 'NaN' is returned.
        /// </returns>
        /// 
        public static double ArithmeticMean(List<double> l)
        {
            double average = double.NaN; // Use this value to signal that the list 'l' is empty.

            // If the numbers in 'l' are very large, there is a risk that summing them will cause numeric  
            // overflow (i.e. the sum is greater than the largest value that can be represented as a 'double'
            // or the sum is smaller than the smallest negative value that can be represented as a 'double').
            // double.MaxValue = 1.79769313486232E+308 (1.79769313486232 x 10^308)
            // double.MinValue = -1.79769313486232E+308 (-1.79769313486232 x 10^308)
            // See https://stackoverflow.com/questions/1930454/what-is-a-good-solution-for-calculating-an-average-where-the-sum-of-all-values-e  
            // for a good discussion on how this problem can be tackled. The code examples are written in Java but
            // should be accessible to anyone with a working knowledge of C#.

            if (l.Count > 0)
            {
                double sum = 0;

                for (int i = 0; i < l.Count; i++)
                {
                    sum += l[i]; //Adding 'l[i]' to 'sum' could result in numeric overflow
                }
                average = sum / l.Count; // If 'sum' has a value of 'NaN', this division results in 'NaN'.
            }

            return average;
        }


        /// <summary>
        /// 'ArithmeticMean' finds the arithmetic mean of an array of <i>double</i> values.
        /// </summary>
        /// <param name="a">
        /// Any array of <i>double</i> values.
        /// </param>
        /// <returns> 
        /// The arithmetic mean (average) of the values in <i>a</i>.
        /// If <i>a</i> is empty, <i>double.NaN</i> is returned.
        /// </returns>

        public static double ArithmeticMean(double[] a)
        {
            // Like lists, arrays can also be empty. This happens when an array has ZERO elements.
            // Since the size of an array cannot change after it has been created, it's difficult
            // to imagine why there would ever be a need to create an array that can't store any data!
            // Normally, there is no good reason to create an array with ZERO elements. However, if a method
            // returns an array, returning an empty array is a convenient way of signalling that something went
            // wrong or that there were no solutions to the problem.
            // Example: Write a method that returns the real roots of a quadratic equation. An empty array can be
            // returned when there are no real roots.

            double average = double.NaN;

            if (a.Length > 0)
            {
                double sum = 0;

                for (int i = 0; i < a.Length; i++)
                {
                    sum += a[i]; // Adding 'a[i]' to 'sum' could result in numeric overflow
                                 // You don't need to worry about this.   
                }
                average = sum / a.Length;
            }

            return average;
        }


        /// <summary>
        /// 'Median' finds the median of a list of <i>double</i> values.
        /// </summary>
        /// <param name="l">
        /// Any list of double values.
        /// </param>
        /// <returns> 
        /// The median of the values in <i>l</i>.
        /// If <i>l</i> is empty, <i>double.NaN</i> is returned.
        /// </returns>

        public static double Median(List<double> l)
        {
            double median = double.NaN;
            if (l.Count > 0)
            {
                l.Sort();
                if (l.Count % 2 != 0) //checks if the number of values in the list is even
                {
                    median = l[l.Count / 2];
                }
                else //number of values in the list is odd
                {
                    double smallerMiddle = l[(l.Count / 2) - 1];
                    double largerMiddle = l[l.Count / 2];
                    median = (smallerMiddle + largerMiddle) / 2;
                }
            }

            return median;
        }

        /// <summary>
        /// 'Median' finds the median of a list of <i>double</i> values.
        /// </summary>
        /// <param name="a">
        /// Any list of double values.
        /// </param>
        /// <returns> 
        /// The median of the values in 'a'.
        /// If 'a' is empty, <i>double.NaN</i> is returned.
        /// </returns>

        public static double Median(double[] a)
        {
            double median = double.NaN;
            if (a.Length > 0)
            {
                Array.Sort(a);
                if (a.Length % 2 != 0) //checks if the number of values in the array is even
                {
                    median = a[a.Length / 2];
                }
                else //number of values in the list is odd
                {
                    double smallerMiddle = a[(a.Length / 2) - 1];
                    double largerMiddle = a[a.Length / 2];
                    median = (smallerMiddle + largerMiddle) / 2;
                }
            }

            return median;
        }


        /// <summary>
        /// 'Mode' finds the mode(s) of a list of <i>double</i> values.
        /// </summary>
        /// <param name="l">
        /// Any list of <i>double</i> values.
        /// </param>
        /// <returns> 
        /// A list of <i>double</i> values containing all the modes of the values in <i>l</i>.
        /// If <i>l</i> is empty, an empty list is returned.
        /// </returns>

        public static List<double> Mode(List<double> l)
        {
            List<double> modeList = new List<double>();

            int maxCount = 0;
            for (int i = 0; i < l.Count; i++)
            {
                int count = 0;
                for (int x = 0; x < l.Count; x++) //keeps track of how many times the ith element shows up in the list
                {
                    if (l[x] == l[i])
                    {
                        count++;
                    }
                }
                if (count > maxCount) //if the ith element shows up more times in the list than the previous mode 
                {
                    maxCount = count;
                    modeList.Clear();
                    modeList.Add(l[i]);
                }
                else if (count == maxCount) //if another mode has been found
                {
                    modeList.Add(l[i]);
                }
            }
            List<double> noRepeatModeList = modeList.Distinct().ToList(); //to get rid of any repetitions in modeList

            return noRepeatModeList;
        }

        /// <summary>
        /// 'Mode' finds the mode(s) of an array of <i>double</i> values.
        /// </summary>
        /// <param name="a">
        /// Any array of <i>double</i> values.
        /// </param>
        /// <returns> 
        /// An array of <i>double</i> values containing all the modes of the values in <i>a</i>.
        /// If <i>a</i> is empty, an empty array is returned.
        /// </returns>

        public static double[] Mode(double[] a)
        {
            // The number of modes of 'a' is initially unknown. Beacause of this, it doesn't make 
            // sense to create an array to store the modes of 'a' yet! Recall that once an array is 
            // created, its size remains fixed. Therefore, the modes are stored temporarily in a list
            // of double values. Once all the modes are known, the list is copied to an array

            List<double> modeList = new List<double>();

            int maxCount = 0;
            for (int i = 0; i < a.Length; i++)
            {
                int count = 0;
                for (int x = 0; x < a.Length; x++) //keeps track of how many times the ith element shows up in the array
                {
                    if (a[x] == a[i])
                    {
                        count++;
                    }
                }
                if (count > maxCount) //if the ith element shows up more times in the array than the previous mode
                {
                    maxCount = count;
                    modeList.Clear();
                    modeList.Add(a[i]);
                }
                else if (count == maxCount) //if another mode has been found
                {
                    modeList.Add(a[i]);
                }
            }
            List<double> noRepeatModeList = modeList.Distinct().ToList(); //to get rid of any repetitions in modeList

            return noRepeatModeList.ToArray();
        }

        /// <summary>'GeometricMean' finds the geometric mean of a list of POSITIVE <i>double</i> values.</summary>
        /// <param name="l">Any list of double values.</param>
        /// <returns> 
        /// The geometric mean of the values in <i>l</i>.
        /// If <i>l</i> is empty, <i>double.NaN</i> is returned.
        /// If <i>l</i> contains any nonpositive values, <i>double.PositiveInfinity</i> is returned.
        /// </returns>

        public static double GeometricMean(List<double> l)
        {
            double geometricMean = double.PositiveInfinity;

            // If the numbers in 'l' are large enough, the product l[0] x l[1] x ... x l[n-1], where n=l.Count, could 
            // result in numeric overflow. To prevent this from happening, it is better to calculate the geometric
            // mean by exploiting properties of logarithms: (1) log(x^n) = nlog(x)    (2) log(xy) = log(x) + log(y)
            //
            // GM = nth root of (l[0] x l[1] x ... x l[n-1])  (GM = geometric mean)
            //    = (l[0] x l[1] x ... x l[n-1])^(1/n)
            //
            // Therefore, log(GM) = log((l[0] x l[1] x ... x l[n-1])^(1/n))
            //                    = (1/n)log(l[0] x l[1] x ... x l[n-1])
            //                    = (1/n)(log(l[0]) + log(l[1]) + ... + log(l[n-1]))
            //                    = (log(l[0]) + log(l[1]) + ... + log(l[n-1])) / n
            // Then GM = base^((log(l[0]) + log(l[1]) + ... + log(l[n-1])) / n), where 'base' is the base used for log.
            //
            // Although this method prevents overflow, it could be susceptible to other problems such as 
            // (1) UNDERFLOW (i.e. produce values that are taken to be zero because they are smaller than the
            //     smallest value that can be represented as a 'double').
            // (2) Evaluating the logarithm is an "expensive" operation for the CPU
            //
            // double.Epsilon = 4.94065645841247E-324 = 4.94065645841247 x 10^(-324) = smallest positive value that
            // can be represented as a 'double'
            // -double.Epsilon = -4.94065645841247E-324 = -4.94065645841247 x 10^(-324) = largest negative value 
            // (i.e. closest to zero) that can be represented as a 'double'.
            // Any value between -double.Epsilon and double.Epsilon is taken to be zero

            for (int i = 0; i < l.Count; i++)
            {
                if (l[i] <= 0)
                {
                    return geometricMean;
                }
            }
            double power = 0; //the variable "power" stores the value of (log (l[0]) + log (l[1]) ... + log(l[n-1])) / n 
            for (int i = 0; i < l.Count; i++)
            {
                power += Math.Log(l[i]);
            }
            power /= l.Count;
            geometricMean = Math.Pow(Math.E, power);

            return geometricMean;
        }

        /// <summary>'GeometricMean' finds the geometric mean of an array of POSITIVE <i>double</i> values.</summary>
        /// <param name="a">Any array of double values.</param>
        /// <returns> 
        /// The geometric mean of the values in <i>a</i>.
        /// If <i>a</i> is empty, <i>double.NaN</i> is returned.
        /// If <i>a</i> contains any nonpositive values, <i>double.PositiveInfinity</i> is returned.
        /// </returns>

        public static double GeometricMean(double[] a)
        {
            double geometricMean = double.PositiveInfinity;

            for (int i = 0; i < a.Length; i++)
            {
                if (a[i] <= 0)
                {
                    return geometricMean;
                }
            }

            double power = 0; //the variable "power" stores the value of (log (l[0]) + log (l[1]) ... + log(l[n-1])) / n 
            for (int i = 0; i < a.Length; i++)
            {
                power += Math.Log(a[i]);
            }
            power /= a.Length;
            geometricMean = Math.Pow(Math.E, power);

            return geometricMean;
        }

        /// <summary>'HarmonicMean' finds the harmonic mean of a list of POSITIVE <i>double</i> values.</summary>
        /// <param name="l">Any list of double values.</param>
        /// <returns> 
        /// The harmonic mean of the values in <i>l</i>.
        /// If <i>l</i> is empty, <i>double.NaN</i> is returned.
        /// If <i>l</i> contains any nonpositive values, <i>double.PositiveInfinity</i> is returned.
        /// </returns>
        public static double HarmonicMean(List<double> l)
        {
            double harmonicMean = double.PositiveInfinity;

            // Let n = l.Count and HM stand for "Harmonic Mean"
            // Then HM = n/(1/l[0] + 1/l[1] + ... + 1/l[n-1]) = n/(sum of reciprocals of values)
            // Overflow and underflow can be an issue for harmonic mean but it's less likely than
            // it is for geometric mean. If the values in the list are very large, then their reciprocals
            // are very small, making the sum of the reciprocals small. Dividing 'n' by a small value
            // can cause overflow in theory but only if 'n' is extremely large. In practice, 'n' has to be 
            // relatively small because of memory limitations. Overflow is more likely to happen if the 
            // values in 'l' are extremely small. For example, if one of the values in the list is double.Epsilon,
            // then 1/double.Epsilon = 1/(4.94065645841247E-324) = [4.94065645841247 x 10^(-324)]^(-1)
            // = (4.94065645841247)^(-1) x 10^[(-324)(-1)] > 5^(-1) x 10^324 = 0.2 x 10^324 = 2 x 10^323, which is
            // far greater than the largest 'double' value.

            for (int i = 0; i < l.Count; i++)
            {
                if (l[i] <= 0)
                {
                    return harmonicMean;
                }
            }
            double sumOfReciprocalsOfValues = 0; 

            for (int i = 0; i < l.Count; i++)
            {
                sumOfReciprocalsOfValues += (1 / l[i]);
            }

            harmonicMean = l.Count / sumOfReciprocalsOfValues;

            return harmonicMean;
        }

        /// <summary>'HarmonicMean' finds the harmonic mean of an array of POSITIVE <i>double</i> values.</summary>
        /// <param name="a">Any array of double values.</param>
        /// <returns> 
        /// The harmonic mean of the values in <i>a</i>.
        /// If <i>a</i> is empty, <i>double.NaN</i> is returned.
        /// If <i>a</i> contains any nonpositive values, <i>double.PositiveInfinity</i> is returned.
        /// </returns>
        public static double HarmonicMean(double[] a)
        {
            double harmonicMean = double.PositiveInfinity;

            for (int i = 0; i < a.Length; i++)
            {
                if (a[i] <= 0)
                {
                    return harmonicMean;
                }
            }

            double sumOfReciprocalsOfValues = 0;

            for (int i = 0; i < a.Length; i++)
            {
                sumOfReciprocalsOfValues += (1 / a[i]);
            }

            harmonicMean = a.Length / sumOfReciprocalsOfValues;

            return harmonicMean;
        }

        #endregion

        #region Min and Max
        /// <summary><i>Minimum</i> finds the smallest value of a list of <i>double</i> values.</summary>
        /// <param name="l">Any list of double values.</param>
        /// <returns> 
        /// The smallest value in <i>l</i>.
        /// If <i>l</i> is empty, <i>double.NaN</i> is returned.
        /// </returns>

        public static double Minimum(List<double> l)
        {
            double min = double.NaN;

            if (l.Count > 0)
            {
                min = l[0]; //Initialize 'min' to the first value in the list.

                for (int i = 1; i < l.Count; i++)
                {
                    if (l[i] < min)
                    {
                        min = l[i];
                    }
                }
            }
            return min;
        }

        /// <summary><i>Minimum</i> finds the smallest value of an array of <i>double</i> values.</summary>
        /// <param name="a">Any array of double values.</param>
        /// <returns> 
        /// The smallest value in <i>a</i>.
        /// If <i>a</i> is empty, <i>double.NaN</i> is returned.
        /// </returns>

        public static double Minimum(double[] a)
        {

            double min = double.NaN;

            if (a.Length > 0)
            {
                min = a[0]; //Initialize 'min' to the first value in the array.

                for (int i = 1; i < a.Length; i++)
                {
                    if (a[i] < min)
                    {
                        min = a[i];
                    }
                }
            }
            return min;
        }

        /// <summary><i>Minimum</i> finds the smallest value of a list of <i>int</i> values.</summary>
        /// <param name="l">Any list of <i>int</i> values.</param>
        /// <returns> 
        /// The smallest value in <i>l</i>.
        /// If <i>l</i> is empty, <i>long.MaxValue</i> is returned.
        /// </returns>
        public static long Minimum(List<int> l)
        {
            // 'long' data type is used to ensure that this method will work   
            // even when 'int.MaxValue' is the smallest value in the list.
            long min = long.MaxValue;

            if (l.Count > 0)
            {
                min = l[0]; //Initialize 'min' to the first value in the list.

                for (int i = 1; i < l.Count; i++)
                {
                    if (l[i] < min)
                    {
                        min = l[i];
                    }
                }
            }
            return min;
        }

        /// <summary><i>IndexOfMinimum</i> finds the INDEX of the smallest value of a list of <i>double</i> values.</summary>
        /// <param name="l">Any list of <i>double</i> values.</param>
        /// <returns> The index of the smallest value in <i>l</i>. If <i>l</i> is empty, -1 is returned.</returns>

        public static int IndexOfMinimum(List<double> l)
        {
            int indexOfMin = -1;

            if (l.Count > 0)
            {
                indexOfMin = 0;

                for (int i = 1; i < l.Count; i++)
                {
                    if (l[i] < l[indexOfMin])
                    {
                        indexOfMin = i;
                    }
                }
            }

            return indexOfMin;
        }

        /// <summary>
        /// <i>IndexOfMinimum</i> finds the INDEX of the smallest value of a list of <i>double</i> values,
        /// from <i>startIndex</i> to the end of the list.
        /// </summary>
        /// <param name="l">Any list of <i>double</i> values.</param>
        /// <param name="startIndex">The index at which the search for the smallest value should begin.</param>
        /// <returns> 
        /// The index of the smallest value in <i>l</i> from <i>startIndex</i> to the end of <i>l</i>.
        /// If <i>l</i> is empty or <i>startIndex</i> is invalid, -1 is returned.
        /// </returns>
        public static int IndexOfMinimum(List<double> l, int startIndex)
        {
            int minIndex = -1;

            if (l.Count > 0 && startIndex >= 0 && startIndex < l.Count)
            {
                for (int i = startIndex + 1; i < l.Count; i++)
                {
                    if (l[i] < l[minIndex])
                    {
                        minIndex = i;
                    }
                }
            }

            return minIndex;
        }

        /// <summary>
        /// <i>IndexOfMinimum</i> finds the INDEX of the smallest value in a list of <i>double</i> values,
        /// from <i>startIndex</i> to <i>endIndex</i>.
        /// </summary>
        /// <param name="l">Any list of <i>double</i> values.</param>
        /// <param name="startIndex">The index at which the search for the smallest value should begin.</param>
        /// <param name="endIndex">The index at which the search for the smallest value should end.</param>
        /// <returns> 
        /// The index of the smallest value in <i>l</i> from <i>startIndex</i> to <i>endIndex</i>.
        /// If <i>l</i> is empty or either of <i>startIndex</i> or <i>endIndex</i> is invalid, -1 is returned.
        /// </returns>

        public static int IndexOfMinimum(List<double> l, int startIndex, int endIndex)
        {
            int indexOfMin = -1;

            if (l.Count > 0 && startIndex >= 0 && startIndex <= endIndex && endIndex < l.Count)
            {
                indexOfMin = startIndex;

                for (int i = startIndex + 1; i <= endIndex; i++)
                {
                    if (l[i] < l[indexOfMin])
                    {
                        indexOfMin = i;
                    }
                }
            }

            return indexOfMin;
        }


        /// <summary><i>Maximum</i> finds the largest value of a list of <i>double</i> values.</summary>
        /// <param name="l">Any list of <i>double</i> values.</param>
        /// <returns>The largest value in <i>l</i>. If <i>l</i> is empty, <i>double.NaN</i> is returned.</returns>

        public static double Maximum(List<double> l)
        {
            double max = double.NaN;

            if (l.Count > 0)
            {
                for (int i = 0; i < l.Count; i++)
                {
                    if (l[i] > max)
                    {
                        max = l[i];
                    }
                }
            }
            return max;
        }

        /// <summary><i>Maximum</i> finds the largest value of an array of <i>double</i> values.</summary>
        /// <param name="a">Any array of <i>double</i> values.</param>
        /// <returns>The largest value in <i>a</i>.If <i>a</i> is empty, <i>double.NaN</i> is returned.</returns>

        public static double Maximum(double[] a)
        {
            double max = double.NaN;

            if (a.Length > 0)
            {
                for (int i = 0; i < a.Length; i++)
                {
                    if (a[i] > max)
                    {
                        max = a[i];
                    }
                }
            }
            return max;
        }

        /// <summary>
        /// <i>Maximum</i> finds the largest value of a list of <i>int</i> values.
        /// </summary>
        /// <param name="l">Any list of <i>int</i>values.</param>
        /// <returns> 
        /// The largest value in <i>l</i>. If <i>l</i> is empty, <i>long.MinValue</i> is returned.</returns>

        public static long Maximum(List<int> l)
        {
            // 'long' data type is used to ensure that this method will work   
            // even when 'int.MinValue' is the largest value in the list.
            long max = long.MinValue;

            if (l.Count > 0)
            {
                for (int i = 0; i < l.Count; i++)
                {
                    if (l[i] > max)
                    {
                        max = l[i];
                    }
                }
            }
            return max;
        }

        /// <summary>
        /// <i>IndexOfMaximum</i> finds the index of largest value of a list of <i>double</i> values.
        /// </summary>
        /// <param name="l">Any list of <i>double</i> values.</param>
        /// <returns> 
        /// The index of the largest value in <i>l</i>.If <i>l</i> is empty, -1 is returned.
        /// </returns>
        public static int IndexOfMaximum(List<double> l)
        {
            int indexOfMax = -1;

            if (l.Count > 0)
            {
                indexOfMax = 0;
                for (int i = 1; i < l.Count; i++)
                {
                    if (l[i] > l[indexOfMax])
                    {
                        indexOfMax = i;
                    }
                }
            }

            return indexOfMax;
        }

        /// <summary>
        /// <i>IndexOfMaximum</i> finds the INDEX of the largest value of a list of <i>double</i> values,
        /// from <i>startIndex</i> to the end of the list.
        /// </summary>
        /// <param name="l">Any list of <i>double</i> values.</param>
        /// <param name="startIndex">The index at which the search for the largest value should begin.</param>
        /// <returns> 
        /// The index of the largest value in <i>l</i> from <i>startIndex</i> to the end of <i>l</i>.
        /// If <i>l</i> is empty or <i>startIndex</i> is invalid, -1 is returned.
        /// </returns>
        public static int IndexOfMaximum(List<double> l, int startIndex)
        {
            int maxIndex = -1;

            if (l.Count > 0)
            {
                for (int i = startIndex + 1; i < l.Count; i++)
                {
                    if (l[i] > l[maxIndex])
                    {
                        maxIndex = i;
                    }
                }
            }

            return maxIndex;
        }

        /// <summary>
        /// <i>IndexOfMaximum</i> finds the INDEX of the largest value of a list of <i>double</i> values,
        /// from <i>startIndex</i> to <i>endIndex</i>.
        /// </summary>
        /// <param name="l">Any list of <i>double</i> values.</param>
        /// <param name="startIndex">The index at which the search for the largest value should begin.</param>
        /// <param name="endIndex">The index at which the search for the largest value should end.</param>
        /// <returns> 
        /// The index of the largest value in <i>l</i> from <i>startIndex</i> to <i>endIndex</i>.
        /// If <i>l</i> is empty or either of <i>startIndex</i> or <i>endIndex</i> is invalid, -1 is returned.
        /// </returns>

        public static int IndexOfMaximum(List<double> l, int startIndex, int endIndex)
        {
            int indexOfMax = -1;

            if (l.Count > 0)
            {
                indexOfMax = startIndex;

                for (int i = startIndex + 1; i <= endIndex; i++)
                {
                    if (l[i] > l[indexOfMax])
                    {
                        indexOfMax = i;
                    }
                }
            }

            return indexOfMax;
        }

        /// <summary><i>QuickSelect</i> finds the kth smallest value of a list of <i>double</i> values.</summary>
        /// <param name="l">Any list of <i>double</i> values.</param>
        /// <param name="k">
        /// Find the <i>k</i>th smallest value. For example, if <i>k</i>=2, the second smallest value is found.
        /// </param>
        /// <returns> 
        /// The <i>k</i>th smallest value in <i>l</i>. If <i>l</i> is empty, <i>double.NaN</i> is returned.
        /// </returns>
        public static double QuickSelect(List<double> l, int k)
        {
            // The quickselect algorithm is similar to quicksort. This isn't a coincidence because  
            // both algorithms were developed by C. A. R. (Tony) Hoare in the late 1950's. 'QuickSelect' 
            // is easy to implement recursively (but would require two more parameters, 'left' and 'right').
            // To avoid recursion for the moment, it is implemented iteratively (i.e. with a loop).

            double kthSmallest = double.NaN;
            int left = 0, right = l.Count - 1; // Begin with the entire list.

            if (l.Count > 0 && k >= 1 && k <= l.Count)
            {
                int pivotIndex = left - 1;
                int kthSmallestIndex = k - 1;

                // Keep partitioning 'l' from 'left' to 'right' until the kth smallest value is the pivot.
                // This happens when pivotIndex = k – 1 because the pivot will be >= all items from index
                // 0 to index k-2. Therefore, k-1 items are <= pivot, making the pivot the kth smallest item.

                while (left < right && kthSmallestIndex != pivotIndex)
                {
                    // Reorganize 'l' in such a way that l = (Left Partition) + pivot + (Right Partition), where
                    // all items in (Left Partition) <= pivot and all items in (Right Partition) >= pivot.
                    pivotIndex = Sorting.LomutoPartition(l, left, right);

                    if (kthSmallestIndex < pivotIndex)
                    {
                        right = pivotIndex - 1; // kth smallest value is between left and pivotIndex-1
                    }
                    else if (kthSmallestIndex > pivotIndex)
                    {
                        left = pivotIndex + 1; // kth smallest value is between pivotIndex+1 and right
                    }
                }

                if (kthSmallestIndex == pivotIndex)
                {
                    kthSmallest = l[kthSmallestIndex];
                }
                else
                {
                    kthSmallest = l[left];
                }
            }

            return kthSmallest;
        }

        /// <summary>
        /// <i>QuickSelect</i> finds the <i>k</i>th smallest value, from index <i>left</i> to index <i>right</i> 
        /// inclusive, in a list of <i>double</i> values.
        /// </summary>
        /// <param name="l">Any list of <i>double</i> values.</param>
        /// <param name="k">
        /// Find the <i>k</i>th smallest value. For example, if <i>k</i>=2, the second smallest value is found.
        /// </param>
        /// <param name="left">The leftmost index.</param>
        /// <param name="right">The rightmost index.</param>
        /// <returns> 
        /// The <i>k</i>th smallest value in <i>l</i> from index <i>left</i> to index <i>right</i> inclusive.
        /// If <i>l</i> is empty, <i>double.NaN</i> is returned.
        /// </returns>

        public static double QuickSelect(List<double> l, int k, int left, int right)
        {
            double kthSmallest = double.NaN;

            if (l.Count > 0 && left >= 0 && left <= right && right < l.Count && k >= 1 && k <= right - left + 1)
            {
                int pivotIndex = left - 1;
                int kthSmallestIndex = left + k - 1;

                // Keep partitioning 'l' from 'left' to 'right' until the kth smallest value is the pivot.
                // This happens when pivotIndex = left + k – 1 because the pivot will be >= all items from index
                // left to index left + k - 2. Therefore, k-1 items are <= pivot, making the pivot the kth smallest 
                // item from index 'left' to index 'right'.

                while (left < right && kthSmallestIndex != pivotIndex)
                {
                    // Reorganize 'l' in such a way that l = (Left Partition) + pivot + (Right Partition), where
                    // all items in (Left Partition) <= pivot and all items in (Right Partition) >= pivot.
                    pivotIndex = Sorting.LomutoPartition(l, left, right);

                    if (kthSmallestIndex < pivotIndex)
                    {
                        right = pivotIndex - 1; // kth smallest value is between left and pivotIndex-1
                    }
                    else if (kthSmallestIndex > pivotIndex)
                    {
                        left = pivotIndex + 1; // kth smallest value is between pivotIndex+1 and right
                    }
                }

                if (kthSmallestIndex == pivotIndex)
                {
                    kthSmallest = l[kthSmallestIndex];
                }
                else
                {
                    kthSmallest = l[left];
                }
            }

            return kthSmallest;
        }
        #endregion

        #region Rounding

        /// <summary>
        /// <i>RoundOff</i> rounds off a value to 'decimalPlaces' places.
        /// No data validation or exception handling has been included in this method.
        /// </summary>
        /// <param name="number">Any <i>double</i> value.</param>
        /// <param name="decimalPlaces">
        /// The number of decimal places to which <i>number</i> should be rounded off.
        /// </param>
        /// <returns><i>number</i> rounded off to <i>decimalPlaces</i> places.</returns>

        public static double RoundOff(double number, int decimalPlaces)
        {
            // When this method is called, a reasonable value should be given to 'decimalPlaces'.
            // Otherwise, the returned value might not make sense or overflow could occur.
            // Overflow can also occur if the the value of 'number' is very large. 
            // No code has been included to check for these possibilities.

            double moveDecPtFactor = Math.Pow(10, decimalPlaces);
            double numDecPtMoved = number * moveDecPtFactor;
            double roundedValue = Math.Floor(numDecPtMoved + 0.5) / moveDecPtFactor;

            // Check whether "numDecPtMoved" ends in 0.5 and "roundedDown" is even
            // In this case, the returned value always needs to be rounded down.
            // e.g. 3.45 to 1 decimal place: 3.45 -> 34.5 -> 34 -> 3.4 (round to even rule)
            double roundedDown = Math.Floor(numDecPtMoved);
            if (numDecPtMoved - roundedDown == 0.5 && roundedDown % 2 == 0)
            {
                roundedValue = Math.Floor(numDecPtMoved) / moveDecPtFactor;
            }

            return roundedValue;
        }

        #endregion

    }
}
